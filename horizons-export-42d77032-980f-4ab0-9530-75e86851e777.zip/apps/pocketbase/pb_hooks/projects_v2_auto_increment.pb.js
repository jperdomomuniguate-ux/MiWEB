/// <reference path="../pb_data/types.d.ts" />
onRecordCreate((e) => {
  // Auto-increment logic for 'no' field
  // Find the highest 'no' value in the collection
  const records = $app.findRecordsByFilter("projects_v2", "", { sort: "-no", limit: 1 });
  
  let nextNo = 1;
  if (records && records.length > 0) {
    const lastRecord = records[0];
    const lastNo = lastRecord.get("no");
    if (lastNo && typeof lastNo === "number") {
      nextNo = lastNo + 1;
    }
  }
  
  // Set the 'no' field to the next sequential number
  e.record.set("no", nextNo);
  e.next();
}, "projects_v2");

import React, { useRef, useEffect } from 'react';
import { cn } from "@/lib/utils";

export default function AutoExpandingTextarea({ className, value, onChange, readOnly, ...props }) {
  const textareaRef = useRef(null);

  const adjustHeight = () => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      const newHeight = Math.min(Math.max(textarea.scrollHeight, 50), 300);
      textarea.style.height = `${newHeight}px`;
    }
  };

  useEffect(() => {
    adjustHeight();
  }, [value]);

  return (
    <textarea
      ref={textareaRef}
      value={value}
      onChange={(e) => {
        if (onChange) onChange(e);
        adjustHeight();
      }}
      readOnly={readOnly}
      className={cn(
        "flex w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 auto-expand-field min-h-[50px] max-h-[300px]",
        readOnly && "bg-muted text-muted-foreground cursor-default focus-visible:ring-0",
        className
      )}
      {...props}
    />
  );
}

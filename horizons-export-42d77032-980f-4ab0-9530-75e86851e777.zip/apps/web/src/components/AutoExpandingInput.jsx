
import React, { useRef, useEffect } from 'react';
import { cn } from "@/lib/utils";

export default function AutoExpandingInput({ className, value, onChange, readOnly, ...props }) {
  const textareaRef = useRef(null);

  const adjustHeight = () => {
    const textarea = textareaRef.current;
    if (textarea) {
      // Reset height to auto to get the correct scrollHeight
      textarea.style.height = 'auto';
      // Set new height bounded by min and max
      const newHeight = Math.min(Math.max(textarea.scrollHeight, 40), 300);
      textarea.style.height = `${newHeight}px`;
    }
  };

  useEffect(() => {
    adjustHeight();
  }, [value]);

  return (
    <textarea
      ref={textareaRef}
      value={value}
      onChange={(e) => {
        if (onChange) onChange(e);
        adjustHeight();
      }}
      readOnly={readOnly}
      rows={1}
      className={cn(
        "flex w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 auto-expand-field min-h-[40px] max-h-[300px]",
        readOnly && "bg-muted text-muted-foreground cursor-default focus-visible:ring-0",
        className
      )}
      {...props}
    />
  );
}

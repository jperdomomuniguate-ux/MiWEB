
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default marker icons in Leaflet with Vite
const redIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

function LocationMarker({ position, setPosition }) {
  useMapEvents({
    click(e) {
      setPosition(e.latlng);
    },
  });

  return position === null ? null : (
    <Marker position={position} icon={redIcon} />
  );
}

export default function InteractiveMapModal({ isOpen, onClose, onConfirm, initialLat, initialLng }) {
  // Default to Guatemala City
  const defaultCenter = { lat: 14.6349, lng: -90.5069 };
  const [position, setPosition] = useState(null);

  useEffect(() => {
    if (isOpen) {
      if (initialLat && initialLng) {
        setPosition({ lat: parseFloat(initialLat), lng: parseFloat(initialLng) });
      } else {
        setPosition(null);
      }
    }
  }, [isOpen, initialLat, initialLng]);

  const handleConfirm = () => {
    if (position) {
      onConfirm(position.lat.toFixed(6), position.lng.toFixed(6));
    }
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-3xl w-[90vw] h-[80vh] max-h-[800px] flex flex-col p-0 gap-0 overflow-hidden bg-background">
        <DialogHeader className="px-6 py-4 border-b border-border shrink-0">
          <DialogTitle className="text-xl font-semibold">Seleccionar Ubicación</DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 relative w-full h-full bg-muted/20">
          {isOpen && (
            <MapContainer 
              center={position || defaultCenter} 
              zoom={12} 
              style={{ height: '100%', width: '100%', zIndex: 10 }}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              <LocationMarker position={position} setPosition={setPosition} />
            </MapContainer>
          )}
        </div>

        <DialogFooter className="px-6 py-4 border-t border-border shrink-0 flex flex-col sm:flex-row items-center justify-between gap-4 bg-background">
          <div className="text-sm text-muted-foreground font-medium">
            {position ? (
              <span>Latitud: <span className="text-foreground">{position.lat.toFixed(6)}</span>, Longitud: <span className="text-foreground">{position.lng.toFixed(6)}</span></span>
            ) : (
              <span>Haga clic en el mapa para colocar un marcador</span>
            )}
          </div>
          <div className="flex gap-3 w-full sm:w-auto">
            <Button variant="outline" onClick={onClose} className="flex-1 sm:flex-none">
              Cancelar
            </Button>
            <Button 
              onClick={handleConfirm} 
              disabled={!position}
              className="flex-1 sm:flex-none bg-primary text-primary-foreground hover:bg-primary/90"
            >
              Confirmar Ubicación
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

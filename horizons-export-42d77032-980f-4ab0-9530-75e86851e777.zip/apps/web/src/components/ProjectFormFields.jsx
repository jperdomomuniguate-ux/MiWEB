
import React, { useState } from 'react';
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { MapPin, Trash2 } from "lucide-react";
import SearchableListbox from './SearchableListbox.jsx';
import AutoExpandingInput from './AutoExpandingInput.jsx';
import InteractiveMapModal from './InteractiveMapModal.jsx';
import { 
  financingSources, urbanisticCoordinations, municipalRegions, 
  neighborhoods, zones, districts, municipalStrategies, 
  prosperousNeighborhoodAxes, priorities, currentStages, staffMembers
} from '../lib/ProjectFormData.js';

export default function ProjectFormFields({ formData, setFormData, creationDate }) {
  const [isMapModalOpen, setIsMapModalOpen] = useState(false);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleLocationConfirm = (lat, lng) => {
    setFormData(prev => ({
      ...prev,
      latitude: lat,
      longitude: lng
    }));
  };

  const typeLabel = formData.projectType === 'Programa' ? 'Programa' : 'Proyecto';
  const staffNamesOnly = staffMembers.map(s => s.name);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
      <div className="space-y-2">
        <Label>No. (Autogenerado)</Label>
        <AutoExpandingInput 
          value={formData.id ? formData.no : 'Se generará al guardar'} 
          readOnly={true}
          className="bg-muted text-muted-foreground border-transparent focus-visible:ring-0"
        />
      </div>
      <div className="space-y-2">
        <Label>Fecha de Creación</Label>
        <AutoExpandingInput 
          value={creationDate || ''} 
          readOnly={true}
          className="bg-muted text-muted-foreground border-transparent focus-visible:ring-0"
        />
      </div>

      <div className="space-y-3 md:col-span-2 pb-4 border-b border-border">
        <Label className="text-base font-semibold">Tipo de Proyecto <span className="text-destructive">*</span></Label>
        <Select value={formData.projectType} onValueChange={(val) => handleChange('projectType', val)}>
          <SelectTrigger className="w-full md:w-1/2">
            <SelectValue placeholder="Seleccione el tipo..." />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Proyecto">Proyecto</SelectItem>
            <SelectItem value="Programa">Programa</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {formData.projectType === 'Programa' && (
        <div className="md:col-span-2 space-y-4 mb-2 p-5 border border-border rounded-xl bg-card shadow-sm animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium">Tipo de intervención</h3>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox 
              id="toggle-interventions" 
              checked={formData.interventions && formData.interventions.length > 0}
              onCheckedChange={(checked) => {
                if (checked) {
                  handleChange('interventions', [{ name: '', type: [] }]);
                } else {
                  handleChange('interventions', []);
                }
              }}
            />
            <Label htmlFor="toggle-interventions" className="cursor-pointer">
              Agregar intervención
            </Label>
          </div>

          {formData.interventions && formData.interventions.length > 0 && (
            <div className="space-y-6 mt-4">
              {formData.interventions.map((inv, idx) => (
                <div key={idx} className="relative p-5 border border-border rounded-lg bg-background flex flex-col gap-5 shadow-sm transition-all duration-200 hover:shadow-md">
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                    onClick={() => {
                      const newInv = [...formData.interventions];
                      newInv.splice(idx, 1);
                      handleChange('interventions', newInv);
                    }}
                    title="Eliminar intervención"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>

                  <div className="space-y-2 pr-8">
                    <Label>Nombre de Intervención</Label>
                    <AutoExpandingInput 
                      value={inv.name} 
                      onChange={(e) => {
                        const newInv = [...formData.interventions];
                        newInv[idx].name = e.target.value;
                        handleChange('interventions', newInv);
                      }} 
                      placeholder="Ej. Construcción de parque comunal"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Tipo de Intervención</Label>
                    <SearchableListbox 
                      options={['Infraestructura / Obra', 'Actividad / Programa', 'Guía / Manual / Documento']} 
                      selectedValues={inv.type || []} 
                      onChange={(val) => {
                        const newInv = [...formData.interventions];
                        newInv[idx].type = val;
                        handleChange('interventions', newInv);
                      }}
                      placeholder="Seleccionar tipo..." 
                    />
                  </div>
                </div>
              ))}

              <div className="flex items-center space-x-2 pt-2">
                <Checkbox 
                  id="add-more-intervention" 
                  checked={false}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      handleChange('interventions', [...formData.interventions, { name: '', type: [] }]);
                    }
                  }}
                />
                <Label htmlFor="add-more-intervention" className="cursor-pointer text-primary font-medium">
                  Agregar otra intervención
                </Label>
              </div>
            </div>
          )}
        </div>
      )}

      {formData.projectType && (
        <>
          <div className="space-y-2">
            <Label htmlFor="projectName">Nombre del {typeLabel} <span className="text-destructive">*</span></Label>
            <AutoExpandingInput 
              id="projectName" 
              value={formData.projectName} 
              onChange={(e) => handleChange('projectName', e.target.value)} 
              placeholder={`Ej. ${typeLabel} Central`}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="projectCode">Código del {typeLabel} <span className="text-destructive">*</span></Label>
            <AutoExpandingInput 
              id="projectCode" 
              value={formData.projectCode} 
              onChange={(e) => handleChange('projectCode', e.target.value)} 
              placeholder="Ej. PRJ-2026-001"
            />
          </div>

          <div className="space-y-2">
            <Label>Fuente de Financiamiento</Label>
            <SearchableListbox 
              options={financingSources} 
              selectedValues={formData.financingSource} 
              onChange={(val) => handleChange('financingSource', val)}
              placeholder="Seleccionar fuentes..." 
            />
          </div>

          <div className="space-y-2">
            <Label>Coordinación Urbanística</Label>
            <SearchableListbox 
              options={urbanisticCoordinations} 
              selectedValues={formData.urbanisticCoordination} 
              onChange={(val) => handleChange('urbanisticCoordination', val)}
              placeholder="Seleccionar coordinación..." 
            />
          </div>

          <div className="space-y-2">
            <Label>Coordinador/a</Label>
            <SearchableListbox 
              options={staffNamesOnly} 
              selectedValues={formData.coordinator} 
              onChange={(val) => handleChange('coordinator', val)}
              placeholder="Seleccionar coordinador(es)..." 
            />
          </div>

          <div className="space-y-2">
            <Label>Integrantes</Label>
            <SearchableListbox 
              options={staffNamesOnly} 
              selectedValues={formData.members} 
              onChange={(val) => handleChange('members', val)}
              placeholder="Seleccionar integrantes..." 
            />
          </div>

          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="emails">Correos (Autogenerado)</Label>
            <AutoExpandingInput 
              id="emails" 
              value={formData.emails || ''} 
              readOnly={true}
              placeholder="Los correos se autogeneran al seleccionar personal"
              className="bg-muted text-muted-foreground border-transparent focus-visible:ring-0"
            />
          </div>

          <div className="space-y-2">
            <Label>Región Municipal</Label>
            <SearchableListbox 
              options={municipalRegions} 
              selectedValues={formData.municipalRegion} 
              onChange={(val) => handleChange('municipalRegion', val)}
              placeholder="Seleccionar región..." 
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="colonia">Colonia</Label>
            <AutoExpandingInput 
              id="colonia" 
              value={formData.colonia} 
              onChange={(e) => handleChange('colonia', e.target.value)} 
            />
          </div>

          <div className="space-y-2">
            <Label>Vecindario</Label>
            <SearchableListbox 
              options={neighborhoods} 
              selectedValues={formData.neighborhood} 
              onChange={(val) => handleChange('neighborhood', val)}
              placeholder="Seleccionar vecindario..." 
            />
          </div>

          <div className="space-y-2">
            <Label>Zona</Label>
            <SearchableListbox 
              options={zones} 
              selectedValues={formData.zone} 
              onChange={(val) => handleChange('zone', val)}
              placeholder="Seleccionar zona..." 
            />
          </div>

          <div className="space-y-2">
            <Label>Distrito</Label>
            <SearchableListbox 
              options={districts} 
              selectedValues={formData.district} 
              onChange={(val) => handleChange('district', val)}
              placeholder="Seleccionar distrito..." 
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Dirección</Label>
            <AutoExpandingInput 
              id="address" 
              value={formData.address} 
              onChange={(e) => handleChange('address', e.target.value)} 
            />
          </div>

          <div className="space-y-2">
            <Label>Ubicación del {typeLabel}</Label>
            <Button 
              variant="outline" 
              className="w-full justify-start text-foreground h-10 hover:bg-accent hover:text-accent-foreground transition-colors" 
              onClick={() => setIsMapModalOpen(true)}
              type="button"
            >
              <MapPin className="mr-2 h-4 w-4 text-primary" />
              {formData.latitude && formData.longitude ? 'Actualizar ubicación en el mapa' : 'Seleccionar en el mapa'}
            </Button>
          </div>

          <div className="space-y-2">
            <Label>Latitud y Longitud</Label>
            <div className="flex gap-2">
              <AutoExpandingInput 
                value={formData.latitude ? `Lat: ${formData.latitude}` : ''} 
                readOnly={true} 
                placeholder="Latitud" 
                className="bg-muted text-muted-foreground border-transparent focus-visible:ring-0"
              />
              <AutoExpandingInput 
                value={formData.longitude ? `Lon: ${formData.longitude}` : ''} 
                readOnly={true} 
                placeholder="Longitud" 
                className="bg-muted text-muted-foreground border-transparent focus-visible:ring-0"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Estrategia Municipal a la que contribuye</Label>
            <SearchableListbox 
              options={municipalStrategies} 
              selectedValues={formData.municipalStrategy} 
              onChange={(val) => handleChange('municipalStrategy', val)}
              placeholder="Seleccionar estrategia..." 
            />
          </div>

          <div className="space-y-2">
            <Label>Eje Vecindario Próspero al que contribuye</Label>
            <SearchableListbox 
              options={prosperousNeighborhoodAxes} 
              selectedValues={formData.neighborhoodAxis} 
              onChange={(val) => handleChange('neighborhoodAxis', val)}
              placeholder="Seleccionar eje..." 
            />
          </div>

          <div className="space-y-2">
            <Label>Prioridad</Label>
            <SearchableListbox 
              options={priorities} 
              selectedValues={formData.priority} 
              onChange={(val) => handleChange('priority', val)}
              placeholder="Seleccionar prioridad..." 
            />
          </div>

          <div className="space-y-2">
            <Label>Etapa Actual</Label>
            <SearchableListbox 
              options={currentStages} 
              selectedValues={formData.currentStage} 
              onChange={(val) => handleChange('currentStage', val)}
              placeholder="Seleccionar etapa..." 
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="avance">Avance</Label>
            <AutoExpandingInput 
              id="avance" 
              value={formData.avance} 
              onChange={(e) => handleChange('avance', e.target.value)} 
              placeholder="Detalle el avance actual..."
            />
          </div>

          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="mapa_procesos">Mapa de Procesos</Label>
            <AutoExpandingInput 
              id="mapa_procesos" 
              value={formData.mapa_procesos} 
              onChange={(e) => handleChange('mapa_procesos', e.target.value)} 
              placeholder="Describa el mapa de procesos..."
            />
          </div>

          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="documentacion">Documentación</Label>
            <AutoExpandingInput 
              id="documentacion" 
              value={formData.documentacion} 
              onChange={(e) => handleChange('documentacion', e.target.value)} 
              placeholder="Enlaces o referencias a documentación..."
            />
          </div>

          <InteractiveMapModal 
            isOpen={isMapModalOpen} 
            onClose={() => setIsMapModalOpen(false)} 
            onConfirm={handleLocationConfirm}
            initialLat={formData.latitude}
            initialLng={formData.longitude}
          />
        </>
      )}
    </div>
  );
}

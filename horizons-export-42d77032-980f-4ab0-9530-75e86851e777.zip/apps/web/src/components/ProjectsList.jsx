
import React, { useState, useEffect } from 'react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  RefreshCw, 
  AlertCircle, 
  FolderOpen, 
  Pencil, 
  Trash2 
} from "lucide-react";
import pb from '../lib/pocketbaseClient.js';
import { toast } from "sonner";

export default function ProjectsList({ refreshTrigger, onEdit }) {
  const [projects, setProjects] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchProjects = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const result = await pb.collection('projects').getList(1, 500, {
        sort: '-created',
        $autoCancel: false
      });
      
      setProjects(result.items);
    } catch (err) {
      console.error("Error fetching projects:", err);
      setError("No se pudieron cargar los proyectos. Por favor, intente de nuevo.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, [refreshTrigger]);

  const handleDelete = async (id) => {
    if (!window.confirm("¿Está seguro de que desea eliminar este registro de forma permanente?")) return;
    try {
      await pb.collection('projects').delete(id, { $autoCancel: false });
      toast.success("Registro eliminado exitosamente.");
      fetchProjects();
    } catch (err) {
      console.error("Error deleting project:", err);
      toast.error("Hubo un problema al intentar eliminar el registro.");
    }
  };

  const formatDate = (dateString, fallbackText = '') => {
    if (!dateString) return fallbackText;
    // Attempt to format if it looks like a standard date, else return verbatim
    if (dateString.includes('-') && dateString.includes(':')) {
      try {
        const date = new Date(dateString);
        return date.toLocaleDateString('es-GT', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric'
        });
      } catch (e) {
        return dateString;
      }
    }
    return dateString;
  };

  if (error) {
    return (
      <div className="w-full p-8 border border-border rounded-xl bg-card flex flex-col items-center justify-center text-center space-y-4 animate-in fade-in duration-300">
        <AlertCircle className="h-12 w-12 text-destructive opacity-80" />
        <div className="space-y-1">
          <h3 className="text-lg font-semibold text-foreground">Error de carga</h3>
          <p className="text-muted-foreground max-w-md">{error}</p>
        </div>
        <Button onClick={fetchProjects} variant="outline" className="mt-2">
          <RefreshCw className="mr-2 h-4 w-4" /> Reintentar
        </Button>
      </div>
    );
  }

  return (
    <div className="w-full space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <h2 className="text-2xl font-bold tracking-tight text-foreground">Registros y Trazabilidad</h2>
        <Button onClick={fetchProjects} variant="outline" size="sm" disabled={isLoading} className="shrink-0">
          <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} /> 
          Actualizar Tabla
        </Button>
      </div>

      <div className="w-full overflow-x-auto rounded-xl border border-border bg-card shadow-sm">
        <div className="inline-block min-w-full align-middle">
          <Table className="relative min-w-full text-sm">
            <TableHeader className="bg-muted/60 sticky top-0 z-10 whitespace-nowrap">
              <TableRow>
                <TableHead className="min-w-[60px]">No.</TableHead>
                <TableHead className="min-w-[140px]">Fecha de Creación</TableHead>
                <TableHead className="min-w-[150px]">Tipo de Proyecto</TableHead>
                <TableHead className="min-w-[220px]">Nombre del Proyecto</TableHead>
                <TableHead className="min-w-[150px]">Código del Proyecto</TableHead>
                <TableHead className="min-w-[200px]">Financiamiento</TableHead>
                <TableHead className="min-w-[220px]">Coordinación Urbanística</TableHead>
                <TableHead className="min-w-[180px]">Coordinador</TableHead>
                <TableHead className="min-w-[160px]">Región Municipal</TableHead>
                <TableHead className="min-w-[160px]">Colonia</TableHead>
                <TableHead className="min-w-[180px]">Barrio</TableHead>
                <TableHead className="min-w-[120px]">Zona</TableHead>
                <TableHead className="min-w-[140px]">Distrito</TableHead>
                <TableHead className="min-w-[250px]">Dirección</TableHead>
                <TableHead className="min-w-[200px]">Estrategia Municipal</TableHead>
                <TableHead className="min-w-[220px]">Eje de Barrio</TableHead>
                <TableHead className="min-w-[120px]">Prioridad</TableHead>
                <TableHead className="min-w-[200px]">Etapa Actual</TableHead>
                <TableHead className="min-w-[100px] sticky right-0 bg-muted/80 backdrop-blur-sm z-20 text-center shadow-[-5px_0_15px_-5px_rgba(0,0,0,0.1)]">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    {Array.from({ length: 19 }).map((_, colIdx) => (
                      <TableCell key={colIdx} className={colIdx === 18 ? "sticky right-0 bg-card z-10" : ""}>
                        <Skeleton className="h-4 w-full min-w-[40px]" />
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : projects.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={19} className="h-64 text-center">
                    <div className="flex flex-col items-center justify-center text-muted-foreground space-y-4 max-w-md mx-auto">
                      <FolderOpen className="h-12 w-12 opacity-40" />
                      <p className="text-lg font-medium text-foreground">No hay proyectos registrados</p>
                      <p className="text-sm">Agregue un nuevo proyecto desde el menú para comenzar a poblar esta tabla.</p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                projects.map((project, index) => (
                  <TableRow key={project.id} className="hover:bg-muted/30 transition-colors whitespace-nowrap group">
                    <TableCell className="font-medium">{index + 1}</TableCell>
                    <TableCell>{project.fecha_creacion || formatDate(project.created)}</TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${
                        project.projectType === 'Programa' 
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300' 
                          : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300'
                      }`}>
                        {project.projectType || 'N/A'}
                      </span>
                    </TableCell>
                    <TableCell className="font-semibold text-primary/90">{project.projectName}</TableCell>
                    <TableCell className="text-muted-foreground">{project.projectCode}</TableCell>
                    <TableCell>{project.financingSource || 'N/A'}</TableCell>
                    <TableCell>{project.urbanisticCoordination || 'N/A'}</TableCell>
                    <TableCell>{project.coordinator || 'N/A'}</TableCell>
                    <TableCell>{project.municipalRegion || 'N/A'}</TableCell>
                    <TableCell>{project.colonia || 'N/A'}</TableCell>
                    <TableCell>{project.neighborhood || 'N/A'}</TableCell>
                    <TableCell>{project.zone || 'N/A'}</TableCell>
                    <TableCell>{project.district || 'N/A'}</TableCell>
                    <TableCell>
                      <div className="max-w-[200px] truncate" title={project.address}>
                        {project.address || 'N/A'}
                      </div>
                    </TableCell>
                    <TableCell>{project.municipalStrategy || 'N/A'}</TableCell>
                    <TableCell>{project.neighborhoodAxis || 'N/A'}</TableCell>
                    <TableCell>
                      {project.priority ? (
                         <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${
                           project.priority.includes('Alta') ? 'bg-red-50 text-red-700 border-red-200 dark:bg-red-900/20' :
                           project.priority.includes('Media') ? 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-900/20' :
                           'bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20'
                         }`}>
                           {project.priority}
                         </span>
                      ) : 'N/A'}
                    </TableCell>
                    <TableCell>{project.currentStage || 'N/A'}</TableCell>
                    <TableCell className="sticky right-0 bg-card/95 group-hover:bg-muted/95 backdrop-blur z-10 shadow-[-5px_0_15px_-5px_rgba(0,0,0,0.05)] border-l border-border transition-colors">
                      <div className="flex items-center justify-center space-x-1 px-2">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-primary hover:text-primary hover:bg-primary/10 transition-transform active:scale-95" 
                          onClick={() => onEdit(project)}
                          title="Editar registro"
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-destructive hover:text-destructive hover:bg-destructive/10 transition-transform active:scale-95"
                          onClick={() => handleDelete(project.id)}
                          title="Eliminar registro"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}

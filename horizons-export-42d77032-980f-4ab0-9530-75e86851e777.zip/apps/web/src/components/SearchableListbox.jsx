
import React, { useState, useRef, useEffect } from 'react';
import { Check, ChevronDown, Search, X } from 'lucide-react';
import { Badge } from "@/components/ui/badge";

export default function SearchableListbox({ 
  options = [], 
  selectedValues = [], 
  onChange, 
  placeholder = "Seleccionar...", 
  searchPlaceholder = "Buscar...",
  label = "Listbox" 
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const wrapperRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    function handleKeyDown(e) {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    }
    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown);
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setSearchTerm('');
    }
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  const filteredOptions = options.filter(opt => {
    const text = typeof opt === 'string' ? opt : opt.name;
    return text.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const handleToggle = (optValue, e) => {
    e.stopPropagation();
    const newValues = selectedValues.includes(optValue)
      ? selectedValues.filter(v => v !== optValue)
      : [...selectedValues, optValue];
    onChange(newValues);
  };

  const removeValue = (optValue, e) => {
    e.stopPropagation();
    onChange(selectedValues.filter(v => v !== optValue));
  };

  return (
    <div className="listbox-wrapper" ref={wrapperRef}>
      <button
        type="button"
        className="listbox-trigger h-auto min-h-[40px] py-1.5"
        onClick={() => setIsOpen(!isOpen)}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        aria-label={label}
      >
        <div className="flex flex-wrap gap-1.5 items-center overflow-y-auto max-h-[200px] pr-2 w-full py-0.5 auto-expand-field">
          {selectedValues.length > 0 ? (
            <>
              {selectedValues.map(val => (
                <Badge key={val} variant="secondary" className="py-0.5 px-2 font-normal flex items-center gap-1">
                  <span className="truncate max-w-[150px]">{val}</span>
                  <span 
                    className="cursor-pointer hover:text-destructive rounded-full p-0.5" 
                    onClick={(e) => removeValue(val, e)}
                  >
                    <X className="h-3 w-3" />
                  </span>
                </Badge>
              ))}
              {selectedValues.length > 1 && (
                <Badge variant="outline" className="ml-auto bg-background text-xs font-medium">
                  {selectedValues.length} seleccionados
                </Badge>
              )}
            </>
          ) : (
            <span className="text-muted-foreground py-1">{placeholder}</span>
          )}
        </div>
        <ChevronDown className={`h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200 ml-2 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="listbox-dropdown" data-state={isOpen ? "open" : "closed"}>
          <div className="listbox-search-wrapper">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <input
                ref={inputRef}
                className="listbox-search-input"
                placeholder={searchPlaceholder}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onClick={(e) => e.stopPropagation()}
              />
            </div>
          </div>
          
          <div className="listbox-options-container" role="listbox" aria-multiselectable="true">
            {filteredOptions.length === 0 ? (
              <div className="py-6 text-center text-sm text-muted-foreground">
                No se encontraron resultados
              </div>
            ) : (
              filteredOptions.map((opt, idx) => {
                const val = typeof opt === 'string' ? opt : opt.name;
                const isSelected = selectedValues.includes(val);
                
                return (
                  <div
                    key={`${val}-${idx}`}
                    className={`listbox-option ${isSelected ? 'selected' : ''}`}
                    role="option"
                    aria-selected={isSelected}
                    onClick={(e) => handleToggle(val, e)}
                  >
                    <div className="listbox-indicator">
                      {isSelected && <Check className="h-4 w-4" />}
                    </div>
                    <span className="truncate">{val}</span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}

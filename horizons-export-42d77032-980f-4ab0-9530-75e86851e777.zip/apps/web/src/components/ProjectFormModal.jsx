
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import ProjectFormFields from './ProjectFormFields.jsx';
import { getEmailsFromSelection } from '../lib/ProjectFormData.js';
import pb from '../lib/pocketbaseClient.js';

const initialFormState = {
  projectType: '',
  projectName: '',
  projectCode: '',
  financingSource: [],
  urbanisticCoordination: [],
  coordinator: [],
  members: [],
  emails: '',
  municipalRegion: [],
  colonia: '',
  neighborhood: [],
  zone: [],
  district: [],
  address: '',
  latitude: '',
  longitude: '',
  municipalStrategy: [],
  neighborhoodAxis: [],
  priority: [],
  currentStage: [],
  interventions: [],
  avance: '',
  mapa_procesos: '',
  documentacion: ''
};

export default function ProjectFormModal({ isOpen, onClose, onSuccess, initialData = null }) {
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState(initialFormState);
  const [creationDate, setCreationDate] = useState('');

  const parseArray = (str) => (str ? str.split(', ').map(s => s.trim()).filter(Boolean) : []);

  useEffect(() => {
    if (isOpen) {
      const today = new Date();
      setCreationDate(`${String(today.getDate()).padStart(2, '0')}/${String(today.getMonth() + 1).padStart(2, '0')}/${today.getFullYear()}`);

      if (!isSaving) {
        setIsLoading(true);
        
        if (initialData) {
          let parsedInterventions = [];
          if (initialData.projectType === 'Programa' && initialData.tipo_intervencion) {
            try {
              parsedInterventions = JSON.parse(initialData.tipo_intervencion);
            } catch (e) {
              // Silently ignore JSON parse errors
            }
          }

          setFormData({
            id: initialData.id,
            no: initialData.no,
            projectType: initialData.projectType || '',
            projectName: initialData.projectName || '',
            projectCode: initialData.projectCode || '',
            financingSource: parseArray(initialData.financingSource),
            urbanisticCoordination: parseArray(initialData.urbanisticCoordination),
            coordinator: parseArray(initialData.coordinator),
            members: parseArray(initialData.members),
            emails: initialData.emails || '',
            municipalRegion: parseArray(initialData.municipalRegion),
            colonia: initialData.colonia || '',
            neighborhood: parseArray(initialData.neighborhood),
            zone: parseArray(initialData.zone),
            district: parseArray(initialData.district),
            address: initialData.address || '',
            latitude: initialData.latitude || '',
            longitude: initialData.longitude || '',
            municipalStrategy: parseArray(initialData.municipalStrategy),
            neighborhoodAxis: parseArray(initialData.neighborhoodAxis),
            priority: parseArray(initialData.priority),
            currentStage: parseArray(initialData.currentStage),
            interventions: parsedInterventions,
            avance: initialData.avance || '',
            mapa_procesos: initialData.mapa_procesos || '',
            documentacion: initialData.documentacion || ''
          });
        } else {
          setFormData(initialFormState);
        }

        setTimeout(() => setIsLoading(false), 300);
      }
    }
  }, [isOpen, initialData]);

  // Derive emails automatically when staff selection changes
  useEffect(() => {
    const emails = getEmailsFromSelection(formData.coordinator, formData.members);
    if (formData.emails !== emails) {
      setFormData(prev => ({ ...prev, emails }));
    }
  }, [formData.coordinator, formData.members]);

  const isFormComplete = () => {
    return !!(
      formData.projectName?.trim() && 
      formData.projectCode?.trim() && 
      formData.projectType?.trim()
    );
  };

  const executeSave = async () => {
    try {
      setIsSaving(true);
      
      const payload = {
        no: formData.no || Math.floor(Math.random() * 10000) + 1, // Let fallback populate the required integer field if missing
        fecha_creacion: formData.id ? initialData.fecha_creacion : creationDate,
        projectName: formData.projectName,
        projectCode: formData.projectCode,
        projectType: formData.projectType,
        financingSource: formData.financingSource.join(', '),
        urbanisticCoordination: formData.urbanisticCoordination.join(', '),
        coordinator: formData.coordinator.join(', '),
        members: formData.members.join(', '),
        emails: formData.emails,
        municipalRegion: formData.municipalRegion.join(', '),
        colonia: formData.colonia,
        neighborhood: formData.neighborhood.join(', '),
        zone: formData.zone.join(', '),
        district: formData.district.join(', '),
        address: formData.address,
        latitude: formData.latitude,
        longitude: formData.longitude,
        municipalStrategy: formData.municipalStrategy.join(', '),
        neighborhoodAxis: formData.neighborhoodAxis.join(', '),
        priority: formData.priority.join(', '),
        currentStage: formData.currentStage.join(', '),
        avance: formData.avance,
        mapa_procesos: formData.mapa_procesos,
        documentacion: formData.documentacion,
        tipo_intervencion: formData.projectType === 'Programa' && formData.interventions?.length > 0 
          ? JSON.stringify(formData.interventions) 
          : ''
      };

      if (formData.id) {
        await pb.collection('projects').update(formData.id, payload, { $autoCancel: false });
        toast.success("Proyecto actualizado exitosamente");
      } else {
        await pb.collection('projects').create(payload, { $autoCancel: false });
        toast.success("Proyecto creado exitosamente");
      }
      
      if (onSuccess) onSuccess();
      setFormData(initialFormState);
      onClose();

    } catch (error) {
      toast.error(error?.data?.message || error.message || "Error al guardar el registro");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col bg-background text-foreground border-border p-0 overflow-hidden shadow-lg rounded-xl">
        <DialogHeader className="px-6 py-4 border-b border-border shrink-0 bg-muted/30">
          <DialogTitle className="text-2xl font-bold text-primary">
            {formData.id ? "Editar Registro" : "Nuevo Registro"}
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto px-6 py-6">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-20 space-y-4">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
              <p className="text-lg font-medium text-muted-foreground">Cargando formulario...</p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="mb-2 pb-2 border-b border-border flex justify-between items-end">
                <div>
                  <h3 className="text-lg font-medium">Detalles del Registro</h3>
                  <p className="text-sm text-muted-foreground">Tipo, Nombre y Código son requeridos.</p>
                </div>
                <div className="text-right text-sm text-muted-foreground">
                  {formData.id && <p>No. {formData.no}</p>}
                  <p>Fecha de Creación: {formData.id ? initialData?.fecha_creacion : creationDate}</p>
                </div>
              </div>
              
              <ProjectFormFields formData={formData} setFormData={setFormData} creationDate={formData.id ? initialData?.fecha_creacion : creationDate} />
            </div>
          )}
        </div>

        {!isLoading && (
          <div className="px-6 py-4 border-t border-border bg-muted/30 shrink-0 flex justify-end">
            <Button variant="outline" onClick={onClose} className="mr-4">
              Cancelar
            </Button>
            <Button 
              onClick={executeSave} 
              disabled={!isFormComplete() || isSaving}
              className="bg-primary text-primary-foreground hover:bg-primary/90 hover:-translate-y-0.5 transition-transform min-w-[140px]"
            >
              {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {formData.id ? "Actualizar" : "Guardar"} {formData.projectType || "Proyecto"}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

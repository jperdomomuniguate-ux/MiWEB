
import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop.jsx';
import HomePage from './pages/HomePage.jsx';
import ProjectsViewPage from './pages/ProjectsViewPage.jsx';
import { Toaster } from "@/components/ui/sonner";

function App() {
    return (
        <Router>
            <ScrollToTop />
            <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/projects" element={<ProjectsViewPage />} />
            </Routes>
            <Toaster position="top-right" />
        </Router>
    );
}

export default App;


import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import ProjectFormModal from '../components/ProjectFormModal.jsx';

const menuItems = [
  {
    id: 'nuevo-registro',
    title: 'Nuevo Registro',
    description: 'programa o proyecto',
    image: 'https://raw.githubusercontent.com/jperdomomuniguate-ux/MiWEB/main/Nuevo.png'
  },
  {
    id: 'proyectos',
    title: 'Proyectos',
    description: 'acciones y trazabilidad',
    image: 'https://raw.githubusercontent.com/jperdomomuniguate-ux/MiWEB/main/folder%20(2).png'
  },
  {
    id: 'mapa',
    title: 'Mapa',
    description: 'intervenciones registradas',
    image: 'https://raw.githubusercontent.com/jperdomomuniguate-ux/MiWEB/main/Map.png'
  },
  {
    id: 'recursos',
    title: 'Recursos',
    description: 'Información de apoyo',
    image: 'https://raw.githubusercontent.com/jperdomomuniguate-ux/MiWEB/main/logistic.png'
  }
];

const HomePage = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const navigate = useNavigate();

  const handleCardClick = (id) => {
    if (id === 'nuevo-registro') {
      setIsModalOpen(true);
    } else if (id === 'proyectos') {
      navigate('/projects');
    } else {
      console.log(`Navigating to section: ${id}`);
    }
  };

  return (
    <div className="relative min-h-screen w-full font-['Montserrat'] overflow-x-hidden bg-background">
      <Helmet>
        <title>Menú Principal | Unidad de Urbanística</title>
        <meta name="description" content="Menú principal de la Unidad de Urbanística de la Municipalidad de Guatemala" />
      </Helmet>

      {/* Hero Section with Background */}
      <div className="relative min-h-screen flex flex-col items-center justify-start p-6 py-0">
        {/* Background Image with Fixed Attachment */}
        <div 
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: 'url(https://raw.githubusercontent.com/jperdomomuniguate-ux/MiWEB/refs/heads/main/ciudad_de_guatemala_ocean_20260506_102625.png)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundAttachment: 'fixed',
            opacity: 0.80
          }}
        />
        
        {/* Gradient Overlay */}
        <div 
          className="absolute inset-0 z-10 pointer-events-none"
          style={{
            background: 'linear-gradient(to bottom, rgba(15,23,42,0.25), rgba(15,23,42,0.85))'
          }}
        />

        {/* Main Content */}
        <div className="app relative z-20 flex flex-col items-center w-full max-w-5xl mx-auto pt-12">
          
          {/* Header Section */}
          <header className="flex flex-col items-center text-center mb-12 space-y-5">
            <img 
              src="https://raw.githubusercontent.com/jperdomomuniguate-ux/MiWEB/refs/heads/main/municipalidad-de-guatemala-logo-png_seeklogo-360090-Photoroom.png"
              alt="Municipalidad de Guatemala Logo"
              className="w-[80px] h-[80px] md:w-[100px] md:h-[100px] object-contain animate-floatLogo"
              style={{
                filter: 'drop-shadow(0 8px 20px rgba(0,0,0,0.55))'
              }}
            />
            
            <h1 className="text-white font-bold text-2xl md:text-4xl leading-tight max-w-3xl tracking-tight">
              Unidad de Urbanística de la<br className="hidden md:block" /> Municipalidad de Guatemala
            </h1>
            
            <div className="inline-flex items-center justify-center px-5 py-1.5 rounded-full bg-slate-900/40 border border-white/10 backdrop-blur-md shadow-lg">
              <span className="text-xs md:text-sm font-semibold tracking-widest text-white/90 uppercase">
                Menú Principal
              </span>
            </div>
          </header>

          {/* Navigation Grid - 2 columns supporting 320px max width cards */}
          <nav className="grid grid-cols-1 sm:grid-cols-2 gap-6 md:gap-8 w-full max-w-[700px] place-items-center justify-center">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleCardClick(item.id)}
                className="card focus:outline-none focus-visible:ring-2 focus-visible:ring-white/50 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
                aria-label={item.title}
              >
                <div className="card-icon">
                  <img 
                    src={item.image} 
                    alt={`Icono de ${item.title}`} 
                    loading="lazy"
                  />
                </div>
                
                <div className="card-content">
                  <h3>{item.title}</h3>
                  <p>{item.description}</p>
                </div>
              </button>
            ))}
          </nav>
        </div>
      </div>

      <ProjectFormModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onSuccess={() => {
          // Optional: Could navigate to projects list upon success
        }}
      />
    </div>
  );
};

export default HomePage;

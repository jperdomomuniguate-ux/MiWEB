
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import ProjectsList from '../components/ProjectsList.jsx';
import ProjectFormModal from '../components/ProjectFormModal.jsx';

export default function ProjectsViewPage() {
  const navigate = useNavigate();
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState(null);

  const handleEdit = (project) => {
    setEditingProject(project);
    setIsEditModalOpen(true);
  };

  const handleSuccess = () => {
    setRefreshTrigger(prev => prev + 1);
    setIsEditModalOpen(false);
    setEditingProject(null);
  };

  const handleClose = () => {
    setIsEditModalOpen(false);
    setEditingProject(null);
  };

  return (
    <div className="min-h-screen bg-background font-['Montserrat']">
      <Helmet>
        <title>Proyectos | Unidad de Urbanística</title>
        <meta name="description" content="Listado de proyectos y trazabilidad de la Unidad de Urbanística" />
      </Helmet>

      {/* Usamos un max-width más amplio para que la tabla masiva encaje mejor */}
      <div className="max-w-[98%] mx-auto px-2 sm:px-4 lg:px-8 py-6 md:py-10 space-y-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="outline" 
            onClick={() => navigate('/')}
            className="hover:bg-muted font-medium"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver al Menú
          </Button>
        </div>

        <div className="bg-card rounded-2xl border border-border shadow-sm p-4 md:p-6 w-full">
          <ProjectsList refreshTrigger={refreshTrigger} onEdit={handleEdit} />
        </div>
      </div>

      <ProjectFormModal 
        isOpen={isEditModalOpen}
        onClose={handleClose}
        onSuccess={handleSuccess}
        initialData={editingProject}
      />
    </div>
  );
}
